import { createIframe } from '../iframe/iframe';
import { initAppOnReady } from '../utils/appUtils';

initAppOnReady(createIframe);
